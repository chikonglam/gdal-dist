var annotated_dup =
[
    [ "Geo", null, [
      [ "GDAL", "classGeo_1_1GDAL.html", "classGeo_1_1GDAL" ],
      [ "GNM", "classGeo_1_1GNM.html", "classGeo_1_1GNM" ],
      [ "OGR", "classGeo_1_1OGR.html", "classGeo_1_1OGR" ],
      [ "OSR", "classGeo_1_1OSR.html", "classGeo_1_1OSR" ]
    ] ],
    [ "our", "classour.html", null ]
];