var classGeo_1_1GDAL_1_1Extent =
[
    [ "ExpandToInclude", "classGeo_1_1GDAL_1_1Extent.html#adf90edf0351749ffe655d82dc1aefbd3", null ],
    [ "IsEmpty", "classGeo_1_1GDAL_1_1Extent.html#aa942cb038cedd3cc105cba53c332bdf9", null ],
    [ "new", "classGeo_1_1GDAL_1_1Extent.html#aaa908458e9aaa398762601ae2b466e9a", null ],
    [ "Overlap", "classGeo_1_1GDAL_1_1Extent.html#aeb1ed50f844601e6b5f4958a7d69a87b", null ],
    [ "Overlaps", "classGeo_1_1GDAL_1_1Extent.html#a1e5050fbe9a954a8256530bbde05a44b", null ],
    [ "Size", "classGeo_1_1GDAL_1_1Extent.html#a5084c6c12f92576d3c68fdfaf3408817", null ]
];