var classGeo_1_1GDAL_1_1MajorObject =
[
    [ "Description", "classGeo_1_1GDAL_1_1MajorObject.html#afd7d59aa8a5b2eefb9c4416a38dda0e6", null ],
    [ "Domains", "classGeo_1_1GDAL_1_1MajorObject.html#abe761762f8e57957b046f2943a26728d", null ],
    [ "GetDescription", "classGeo_1_1GDAL_1_1MajorObject.html#a681e984021afd2d94be817f914cf8ffc", null ],
    [ "GetMetadata", "classGeo_1_1GDAL_1_1MajorObject.html#a5fd65fa7213850d657c55fc1c52e7d15", null ],
    [ "GetMetadataDomainList", "classGeo_1_1GDAL_1_1MajorObject.html#afefd8c46400929d33d348db566e289c4", null ],
    [ "Metadata", "classGeo_1_1GDAL_1_1MajorObject.html#aeac3f4a87685d6ed70a51ce1ef61b865", null ],
    [ "SetDescription", "classGeo_1_1GDAL_1_1MajorObject.html#ad732018e9f2f7824e93072a136ade4cb", null ],
    [ "SetMetadata", "classGeo_1_1GDAL_1_1MajorObject.html#ae17c202f803923e71ca255d4465f4378", null ]
];