var classGeo_1_1GDAL_1_1Transformer =
[
    [ "new", "classGeo_1_1GDAL_1_1Transformer.html#ab8474a986eadd365b2caa4334d6389e3", null ],
    [ "TransformGeolocations", "classGeo_1_1GDAL_1_1Transformer.html#a6815fafb7f52ed882c060243c2f15a5d", null ],
    [ "TransformPoint", "classGeo_1_1GDAL_1_1Transformer.html#aa4994f3a2968aef678d0068be0c5ea27", null ]
];