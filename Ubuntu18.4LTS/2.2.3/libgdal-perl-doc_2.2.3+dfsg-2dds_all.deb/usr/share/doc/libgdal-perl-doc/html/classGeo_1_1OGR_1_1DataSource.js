var classGeo_1_1OGR_1_1DataSource =
[
    [ "Open", "classGeo_1_1OGR_1_1DataSource.html#ae79b06b48c56e4d0dab062785650ea17", null ],
    [ "OpenShared", "classGeo_1_1OGR_1_1DataSource.html#a90dae23f1967b031d2d3d20d2db03d75", null ]
];