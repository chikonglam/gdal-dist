var classGeo_1_1OGR_1_1FeatureDefn =
[
    [ "AddField", "classGeo_1_1OGR_1_1FeatureDefn.html#a8167605fe67cc10409c3d9c6437825dd", null ],
    [ "DeleteField", "classGeo_1_1OGR_1_1FeatureDefn.html#afe37e1619a808b124593287900f5691d", null ],
    [ "Feature", "classGeo_1_1OGR_1_1FeatureDefn.html#a497033a11437f14528449235b0121653", null ],
    [ "GetFieldDefn", "classGeo_1_1OGR_1_1FeatureDefn.html#a09cb55e8d13fb7165c8e304ae58da9c1", null ],
    [ "GetFieldNames", "classGeo_1_1OGR_1_1FeatureDefn.html#a164147ef31845f3b3eb28fb2cf7780c4", null ],
    [ "GetGeomFieldDefn", "classGeo_1_1OGR_1_1FeatureDefn.html#aa2474c5daf3b65a94612e40ed70cb6de", null ],
    [ "GetName", "classGeo_1_1OGR_1_1FeatureDefn.html#a5eee2ad3f817ea5d53305245693420b7", null ],
    [ "GetSchema", "classGeo_1_1OGR_1_1FeatureDefn.html#a607d90979167b7b0968407cb49759035", null ],
    [ "IsSame", "classGeo_1_1OGR_1_1FeatureDefn.html#a189a4856f982d2371bcbc0ebd0c0ac0e", null ],
    [ "IsStyleIgnored", "classGeo_1_1OGR_1_1FeatureDefn.html#a854be38e3e679723c48cae079be8742b", null ],
    [ "new", "classGeo_1_1OGR_1_1FeatureDefn.html#a95ae03e96b953ab6178b66d7eb838b7f", null ],
    [ "RELEASE_PARENT", "classGeo_1_1OGR_1_1FeatureDefn.html#ac6291a6b42cf3bc6abff18aa1bf8fe8a", null ],
    [ "SetStyleIgnored", "classGeo_1_1OGR_1_1FeatureDefn.html#a2a83770e0f66e14ed96d342235ef0941", null ]
];