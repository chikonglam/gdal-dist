var classGeo_1_1OGR_1_1FieldDefn =
[
    [ "Default", "classGeo_1_1OGR_1_1FieldDefn.html#a03e596b745859f8be96a2c69940721c4", null ],
    [ "GetSchema", "classGeo_1_1OGR_1_1FieldDefn.html#af50d5a54d8aab5ba7cb1f25afa4a61ba", null ],
    [ "Ignored", "classGeo_1_1OGR_1_1FieldDefn.html#a1d115fd93fab4f1c027e30e3cb292bda", null ],
    [ "IsDefaultDriverSpecific", "classGeo_1_1OGR_1_1FieldDefn.html#a7d628dd6f8eb569a2549f08048fe0ef2", null ],
    [ "Justify", "classGeo_1_1OGR_1_1FieldDefn.html#a183b9574fcdceed4c1ee1cd10015c249", null ],
    [ "JustifyValues", "classGeo_1_1OGR_1_1FieldDefn.html#ab33f2645019230a1889b2aa01659b74b", null ],
    [ "Name", "classGeo_1_1OGR_1_1FieldDefn.html#a4cfdafa14c7a409daf5d9ec31e3bb33b", null ],
    [ "new", "classGeo_1_1OGR_1_1FieldDefn.html#a02f94b3023e631aad8574caf0eff8491", null ],
    [ "Nullable", "classGeo_1_1OGR_1_1FieldDefn.html#a744ddc6a5ff5855157cfe7c9f52a82d7", null ],
    [ "Precision", "classGeo_1_1OGR_1_1FieldDefn.html#a56a888b742684cff175ae629d28132ca", null ],
    [ "Schema", "classGeo_1_1OGR_1_1FieldDefn.html#a8ee1a5b4c2e457e95b9605fec8f78ec1", null ],
    [ "SetSchema", "classGeo_1_1OGR_1_1FieldDefn.html#aebb8d924eaed6b2cf5d37594e956bc11", null ],
    [ "SubType", "classGeo_1_1OGR_1_1FieldDefn.html#a531f6a224e737aa5281fe1a7c4a71d98", null ],
    [ "SubTypes", "classGeo_1_1OGR_1_1FieldDefn.html#ad9743493d823d55da1637de7eeaf6669", null ],
    [ "Type", "classGeo_1_1OGR_1_1FieldDefn.html#a19101ff997103b76ef7efa4a25a58497", null ],
    [ "Types", "classGeo_1_1OGR_1_1FieldDefn.html#ad55fceec1e1598c7c3529fff8fc5fb3e", null ],
    [ "Width", "classGeo_1_1OGR_1_1FieldDefn.html#ae7cb1b8e0e1648d0e787150ae1a4260a", null ]
];