var classGeo_1_1OGR_1_1GeomFieldDefn =
[
    [ "GeometryType", "classGeo_1_1OGR_1_1GeomFieldDefn.html#ae1759e7e87a8977287e8f7bc1af6d708", null ],
    [ "GetSchema", "classGeo_1_1OGR_1_1GeomFieldDefn.html#a75ff96b457c95a7e331991a1755f99bf", null ],
    [ "Ignored", "classGeo_1_1OGR_1_1GeomFieldDefn.html#a9f68a9e5a257b68bf31f61d140204653", null ],
    [ "Name", "classGeo_1_1OGR_1_1GeomFieldDefn.html#ad16749c67e60dd033df9e80dbd81d038", null ],
    [ "new", "classGeo_1_1OGR_1_1GeomFieldDefn.html#a390438ea74069f3ed6cc79935c986830", null ],
    [ "Nullable", "classGeo_1_1OGR_1_1GeomFieldDefn.html#a454993f4a1b7542898d43307b94baac8", null ],
    [ "Schema", "classGeo_1_1OGR_1_1GeomFieldDefn.html#ab365a525e4371d449e71b5e7b930b884", null ],
    [ "SetSchema", "classGeo_1_1OGR_1_1GeomFieldDefn.html#a5fcb2522166eb55d8bb3ad8702976662", null ],
    [ "SpatialReference", "classGeo_1_1OGR_1_1GeomFieldDefn.html#adc5da1c6d367b0d70e0349728b605e55", null ],
    [ "Type", "classGeo_1_1OGR_1_1GeomFieldDefn.html#ac2a1dabb56236f8de0cb414c00b335b9", null ],
    [ "Types", "classGeo_1_1OGR_1_1GeomFieldDefn.html#a42a49c867a620dc6bbcf388427e48348", null ]
];