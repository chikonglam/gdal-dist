var classGeo_1_1OSR_1_1CoordinateTransformation =
[
    [ "new", "classGeo_1_1OSR_1_1CoordinateTransformation.html#ac1128cc7a9fede2d297e552dc0dd5e26", null ],
    [ "TransformPoint", "classGeo_1_1OSR_1_1CoordinateTransformation.html#a5a2c700c75c9d5bf8941bdbbdc2e274d", null ],
    [ "TransformPoints", "classGeo_1_1OSR_1_1CoordinateTransformation.html#a0ee6cb6cef42e552249937f0efa39676", null ]
];