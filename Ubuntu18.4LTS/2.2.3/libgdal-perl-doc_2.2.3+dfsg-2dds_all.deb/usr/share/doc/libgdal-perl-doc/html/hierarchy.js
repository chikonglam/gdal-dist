var hierarchy =
[
    [ "Geo::GDAL", "classGeo_1_1GDAL.html", [
      [ "Geo::GDAL::AsyncReader", "classGeo_1_1GDAL_1_1AsyncReader.html", null ],
      [ "Geo::GDAL::Band", "classGeo_1_1GDAL_1_1Band.html", null ],
      [ "Geo::GDAL::ColorTable", "classGeo_1_1GDAL_1_1ColorTable.html", null ],
      [ "Geo::GDAL::Dataset", "classGeo_1_1GDAL_1_1Dataset.html", null ],
      [ "Geo::GDAL::Driver", "classGeo_1_1GDAL_1_1Driver.html", [
        [ "Geo::OGR::Driver", "classGeo_1_1OGR_1_1Driver.html", null ]
      ] ],
      [ "Geo::GDAL::GCP", "classGeo_1_1GDAL_1_1GCP.html", null ],
      [ "Geo::GDAL::MajorObject", "classGeo_1_1GDAL_1_1MajorObject.html", [
        [ "Geo::GDAL::Band", "classGeo_1_1GDAL_1_1Band.html", null ],
        [ "Geo::GDAL::Dataset", "classGeo_1_1GDAL_1_1Dataset.html", null ],
        [ "Geo::GDAL::Driver", "classGeo_1_1GDAL_1_1Driver.html", null ],
        [ "Geo::GNM::Network", "classGeo_1_1GNM_1_1Network.html", [
          [ "Geo::GNM::GenericNetwork", "classGeo_1_1GNM_1_1GenericNetwork.html", null ]
        ] ],
        [ "Geo::OGR::Layer", "classGeo_1_1OGR_1_1Layer.html", null ]
      ] ],
      [ "Geo::GDAL::RasterAttributeTable", "classGeo_1_1GDAL_1_1RasterAttributeTable.html", null ],
      [ "Geo::GDAL::Transformer", "classGeo_1_1GDAL_1_1Transformer.html", null ]
    ] ],
    [ "Geo::GDAL::Extent", "classGeo_1_1GDAL_1_1Extent.html", null ],
    [ "Geo::GDAL::GeoTransform", "classGeo_1_1GDAL_1_1GeoTransform.html", null ],
    [ "Geo::GDAL::XML", "classGeo_1_1GDAL_1_1XML.html", null ],
    [ "Geo::GNM", "classGeo_1_1GNM.html", [
      [ "Geo::GNM::GenericNetwork", "classGeo_1_1GNM_1_1GenericNetwork.html", null ],
      [ "Geo::GNM::Network", "classGeo_1_1GNM_1_1Network.html", null ]
    ] ],
    [ "Geo::GNM::MajorObject", "classGeo_1_1GNM_1_1MajorObject.html", null ],
    [ "Geo::OGR", "classGeo_1_1OGR.html", [
      [ "Geo::OGR::Feature", "classGeo_1_1OGR_1_1Feature.html", null ],
      [ "Geo::OGR::FeatureDefn", "classGeo_1_1OGR_1_1FeatureDefn.html", null ],
      [ "Geo::OGR::FieldDefn", "classGeo_1_1OGR_1_1FieldDefn.html", null ],
      [ "Geo::OGR::Geometry", "classGeo_1_1OGR_1_1Geometry.html", null ],
      [ "Geo::OGR::GeomFieldDefn", "classGeo_1_1OGR_1_1GeomFieldDefn.html", null ],
      [ "Geo::OGR::Layer", "classGeo_1_1OGR_1_1Layer.html", null ],
      [ "Geo::OGR::StyleTable", "classGeo_1_1OGR_1_1StyleTable.html", null ]
    ] ],
    [ "Geo::OGR::DataSource", "classGeo_1_1OGR_1_1DataSource.html", null ],
    [ "Geo::OSR", "classGeo_1_1OSR.html", [
      [ "Geo::OSR::CoordinateTransformation", "classGeo_1_1OSR_1_1CoordinateTransformation.html", null ],
      [ "Geo::OSR::SpatialReference", "classGeo_1_1OSR_1_1SpatialReference.html", null ]
    ] ],
    [ "our", "classour.html", [
      [ "Geo::GDAL::VSIF", "classGeo_1_1GDAL_1_1VSIF.html", null ],
      [ "Geo::OGR::Driver", "classGeo_1_1OGR_1_1Driver.html", null ]
    ] ]
];