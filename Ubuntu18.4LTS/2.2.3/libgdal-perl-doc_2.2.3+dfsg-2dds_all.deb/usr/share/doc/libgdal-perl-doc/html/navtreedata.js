var NAVTREE =
[
  [ "Geo::GDAL", "index.html", [
    [ "Version", "index.html#index_version", null ],
    [ "Introduction", "index.html#index_intro", [
      [ "Usage", "index.html#usage", null ],
      [ "Arguments", "index.html#arguments", null ]
    ] ],
    [ "Modules, package subroutines, class methods, and object methods", "index.html#class_methods_vs_object_methods", null ],
    [ "Exceptions", "index.html#index_exceptions", [
      [ "Environment variable CPL_DEBUG", "index.html#cpl_debug", null ]
    ] ],
    [ "Named parameters", "index.html#index_named_params", null ],
    [ "Progress callback", "index.html#index_progress", null ],
    [ "Redirecting stdout to a writer object", "index.html#index_stdout_redirection", null ],
    [ "Reference counting", "index.html#index_refcount", null ],
    [ "Processing options", "index.html#index_processing_options", null ],
    [ "Note", "index.html#index_footer", null ],
    [ "Creating a raster dataset", "create_raster.html", null ],
    [ "Creating a vector dataset", "create_vector.html", null ],
    [ "Using PDL to manipulate band data", "band_to_pdl.html", null ],
    [ "Reading a raster dataset", "read_raster.html", null ],
    [ "Reading a vector dataset", "read_vector.html", null ],
    [ "Streaming a dataset", "streaming.html", null ],
    [ "Tips and tricks", "tips.html", [
      [ "First few lines", "tips.html#tips_preamble", null ],
      [ "GDAL style progress function in Perl", "tips.html#tips_progress", null ],
      [ "Get the raster coordinates in iteration", "tips.html#tips_raster_coordinates", null ]
    ] ],
    [ "Transforming a dataset", "transform.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classGeo_1_1GDAL_1_1RasterAttributeTable.html#ad436b8573edb992244a04030b3474bbd",
"classGeo_1_1OGR_1_1Geometry.html#acb8a4a6dbea38625ae55c5f35fee1d63"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';